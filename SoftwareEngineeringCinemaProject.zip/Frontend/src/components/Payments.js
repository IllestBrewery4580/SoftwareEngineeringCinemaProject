'use client'

const Payments = () => {
    return (<>
        
    </>
    )
}

export default Payments;